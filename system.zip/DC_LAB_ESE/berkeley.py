import csv

nodes = []

with open("node_clocks_3.csv", "r") as file:
    reader = csv.DictReader(file)

    for row in reader:
        nodes.append(row)

print("Berkeley Clock Synchronization")

total = 0
count = 0

for node in nodes:
    print(f"\n Polling {node['node_id']}:{node['clock_time_sec']} seconds")

    if node["is_faulty"] == "FALSE":
        total += int(node["clock_time_sec"])
        count += 1

    else:
        print("Faulty node excluded")

average = total/count

for node in nodes:
    if node["is_faulty"] == "FALSE":
        current = int(node["clock_time_sec"])
        adjustment = average - current
        new_time = current + adjustment

        print(f"adjustment for node {node['node_id']} is {adjustment} seconds, new time is {new_time} seconds")

print("\nClock synchronization complete")     
