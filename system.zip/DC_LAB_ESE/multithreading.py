
import csv
import os
import threading
import time

task_lock = threading.Lock()
completed_tasks = []


def worker(task):

    task_id = task["task_id"]
    thread_name = task["thread_name"]
    burst_ms = task["burst_ms"]
    priority = task["priority"]

    print(f"\n[{thread_name}] Started Task {task_id}")
    print(f"Priority: {priority}")

    time.sleep(burst_ms / 1000)

    print(f"[{thread_name}] Waiting for lock...")

    with task_lock:
        print(f"[{thread_name}] LOCK ACQUIRED")

        completed_tasks.append(task_id)

        print(f"[{thread_name}] Task {task_id} completed")
        print(f"[{thread_name}] LOCK RELEASED")


def main():

    filename = "multithread.csv"

    if not os.path.exists(filename):
        print("CSV file not found!")
        return

    tasks = []

    with open(filename, "r", newline="") as file:

        reader = csv.DictReader(file)

        for row in reader:

            if row["status"].strip().upper() == "PENDING":

                task = {
                    "task_id": row["task_id"],
                    "thread_name": row["thread_name"],
                    "burst_ms": int(row["burst_ms"]),
                    "priority": row["priority"]
                }

                tasks.append(task)

    if not tasks:
        print("No pending tasks found!")
        return

    print("\n===== MULTITHREADING SIMULATION =====")
    print("[MAIN] Creating worker threads...")

    threads = []

    for task in tasks:

        t = threading.Thread(
            target=worker,
            args=(task,)
        )

        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    print("\n===== FINAL TASK STATUS =====")

    print("All threads completed.")

    for task_id in completed_tasks:
        print("[COMPLETED]", task_id)

    print("Total Completed Tasks:", len(completed_tasks))


if __name__ == "__main__":
    main()
