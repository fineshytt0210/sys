import csv

workers = ["W1","W2","W3"]
loads = {"W1":0,"W2":0,"W3":0}
counts = {"W1":0,"W2":0,"W3":0}

with open("workload_5.csv","r") as file:
    reader = csv.DictReader(file)

    for i,job in enumerate(reader):
        worker = workers[i%len(workers)]
        units = int(job["compute_units"])

        job["assigned_worker"] = worker
        job["status"] = "ASSIGNED"

        loads[worker] += units
        counts[worker] += 1

        print(f"Job {job['job_id']} assigned to {worker}")
        print(f" Current load on {worker}: {loads[worker]}")

print("\nLoad Balancing Summary:")

for worker in workers:
    print(f"{worker}: Total Load = {loads[worker]}, Jobs Assigned = {counts[worker]}")