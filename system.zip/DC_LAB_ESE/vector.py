import csv

clocks = {"P1": [0,0,0], "P2": [0,0,0], "P3": [0,0,0]}
messages = {}
events = {}

with open("vector_events_6.csv", "r") as file:
    reader = csv.DictReader(file)

    for row in reader:
        p = row["process_id"]
        action = row["event_action"]
        other = row["target_process"]
        i = int(p[1]) - 1

        if action == "RECEIVE":
            for j in range(3):
                clocks[p][j] = max(clocks[p][j], messages[other][j])

        clocks[p][i] +=1

        if action == "SEND":
            messages[p] = clocks[p].copy()

        events[row["event_id"]] = clocks[p].copy()
        print(row["event_id"], p, action, other, "Clock:", clocks[p])

print("\n Event comparison:")

for e1 in events:
    for e2 in events:
        if e1>= e2:
            continue

        a = events[e1]
        b = events[e2]

        if all(a[k] <= b[k] for k in range(3)):
            print( e1, "<", e2, "(causal)")
        elif all(b[k] <= a[k] for k in range(3)):
            print( e2, "<", e1, "(causal)")
        else:
            print( e1, "||", e2, "(concurrent)")