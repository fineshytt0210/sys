import csv

def processData(value):
    return value*2

def dispatch(method_name,param_value):
    if method_name == "processData":
        return processData(param_value)
    else :
        return "Method not found"

with open("rpc_calls_1.csv","r") as file:
        reader = csv.DictReader(file)

        for row in reader:
            call_id = row["call_id"]
            method = row["method_name"]
            client = row["client_name"]
            param_value = int(row["param_value"])

            print(f"\n[DISPATCH] {client} calls {method} ({param_value})")

            request={
                "method": method,
                "param": param_value
            }

            print(f"[SERVER EXECUTION] processing {request['param']}")

            result = dispatch(request["method"], request["param"])

            print(f"[RETURN Call {call_id} : esult = {result}   ]")

