import csv

nodes = {}
coordinator = None

with open("bully_cluster_2.csv", "r") as file:
    reader = csv.DictReader(file)

    for row in reader:
        node = int(row["node_id"])
        nodes[node] = row["is_alive"] == "TRUE"

        if nodes[node] == row["is_current_coordinator"] == "True":
            coordinator = node

print(f"Current coordinator is node {coordinator}")
print("coordinator failed, starting election...")

def election(process):
    print(f"Node {process} is starting an election")
    active_higher = []

    for node in sorted(nodes):
        if node > process:
            print(f"P{process} sends ELECTION to P{node}")

            if nodes[node]:
                print(f"P{node} sends OK to P{process}")
                active_higher.append(node)

            else:
                print(f"P{node} is not responding")

    if not active_higher:
           return process

    return election(min(active_higher))

initiator = 1
new_coordinator = election(initiator)

print(f"Node {new_coordinator} is elected as the new coordinator")

print("\n[NEW COORDINATOR ANNOUNCEMENT]")

for node in sorted(nodes):
    if nodes[node] and node != new_coordinator:
        print(f"P{new_coordinator} sends COORDINATOR to P{node}")

print(f"Node {new_coordinator} is now the coordinator of the cluster")