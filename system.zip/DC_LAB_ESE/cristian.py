import csv

with open("cristian_clocks_24.csv", "r") as file:
    reader = csv.DictReader(file)

    for row in reader:
        client = row["client_id"]
        t0 = int(row["t0_send_ms"])
        t_server = int(row["t_server_ms"])
        t1 = int(row["t1_recv_ms"])

        rtt = t1 - t0
        estimated_time = t_server + (rtt / 2)
        adjustment = estimated_time - t1
        new_time = t1 + adjustment

        print(f"\nClient : {client}")
        print(f"Request sent at : {t0} ms")
        print(f"Server time: {t_server} ms")
        print(f"Response received at : {t1} ms")

        print(f"RTT : {rtt} ms")
        print(f"Estimated time : {estimated_time} ms")
        print(f"Clock adjustment : {adjustment} ms")
        print(f"Adjusted client time : {new_time} ms")
