import csv

clocks = {}
messages = {}
events = []

with open("events_7.csv", "r") as file:
    reader = csv.DictReader(file)

    for row in reader:
        p = row["process_id"]
        action = row["event_type"]
        other = row["message_to"]

        if p not in clocks:
            clocks[p] = int(row["initial_clock"])
            

        if action == "RECEIVE":
            clocks[p] = max(clocks[p], messages[other]) + 1

        else:
            clocks[p]+= 1

        if action == "SEND":
            messages[p] = clocks[p]

        events.append((clocks[p], row["event_id"], p))
        print(row["event_id"], p, action,"Clock:", clocks[p])

print("\n Final Event order:")

for time,event, p in sorted(events):
    print(event, p, "Clock:", time)

