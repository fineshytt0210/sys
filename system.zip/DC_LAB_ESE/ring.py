import csv

nodes = {}

with open ("ring_nodes_31.csv", "r") as file:
    reader = csv.DictReader(file)

    for row in reader:
        node = int(row["node_id"])
        nodes[node] = {
            'next' : int(row["next_node_id"]),
            'active' : row["is_active"] == "TRUE"
        }

print("Coordinator has failed")

initiator = 1
current = initiator
active_nodes = []

print(f"p{initiator} is starting an election")

while True:
    if nodes[current]['active']:
        active_nodes.append(current)
        print(f"P{current} participates in the election")

    else:
        print(f"P{current} is inactive, skipped")

    print(f"P{current} sends ELECTION to P{nodes[current]['next']}")    

    current = nodes[current]["next"]

    if current == initiator:
        break

coordinator = max(active_nodes)

print(f"P {coordinator} is elected as the new coordinator")

for nodes in active_nodes:
    print(f"P{coordinator} sends COORDINATOR to P{nodes}")