import csv
import threading

A = []
B = []
C = []
threads = []

with open("matrix_30.csv", "r") as file:
    reader = csv.DictReader(file)

    for row in reader:
        A.append([int(row["col_0"]), int(row["col_1"]), int(row["col_2"]), int(row["col_3"])])

B = A
C = [None] * len(A)

def multiply(i):
    result = []

    for j in range(4):
        total = 0
        for k in range(4):
            total += A[i][k] * B[k][j]
        result.append(total)

    C[i] = result
    print("worker:", i, "calculated:", result)

print("Master scattering nodes")

for i in range(len(A)):
    t = threading.Thread(target = multiply, args = (i,))
    threads.append(t)
    t.start()

for t in threads:
    t.join()

print("\nMaster gathering results")

for row in C:
    print(row)